const { getRelationshipAttribute } = require("../TwinCentralAPI");

getRelationshipAttribute()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
