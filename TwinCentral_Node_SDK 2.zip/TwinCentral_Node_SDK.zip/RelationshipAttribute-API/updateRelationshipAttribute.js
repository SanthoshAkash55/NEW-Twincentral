const { updateRelationshipAttribute } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("id: ", async (id) => {
    rl.question(
      "objectRelationshipObjectID: ",
      async (objectRelationshipObjectID) => {
        rl.question("attributeID: ", async (attributeID) => {
          rl.question("value: ", async (value) => {
            rl.question("activatedOn: ", async (activatedOn) => {
              rl.question("deactivatedOn: ", async (deactivatedOn) => {
                rl.question("Is Active? (true/false): ", async (isActive) => {
                  // Create an object with the entered data
                  const response = await updateRelationshipAttribute(
                    Id,
                    parseInt(id),
                    parseInt(objectRelationshipObjectID),
                    parseInt(attributeID),
                    value,
                    activatedOn,
                    deactivatedOn,
                    isActive
                  );
                  console.log(response);
                  rl.close();
                });
              });
            });
          });
        });
      }
    );
  });
});
