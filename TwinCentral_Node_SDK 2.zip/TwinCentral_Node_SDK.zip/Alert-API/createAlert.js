const { createAlert } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("id: ", async (id) => {
  rl.question("alertDateTime: ", async (alertDateTime) => {
    rl.question("dashboardID: ", async (dashboardID) => {
      rl.question("alertDestinationID: ", async (alertDestinationID) => {
        rl.question("subject: ", async (subject) => {
          rl.question("message: ", async (message) => {
            rl.question("url: ", async (url) => {
              rl.question("custom1: ", async (custom1) => {
                rl.question("custom2: ", async (custom2) => {
                  rl.question("status: ", async (status) => {
                    // Create an object with the entered data
                    const response = await createAlert(
                      parseInt(id),
                      alertDateTime,
                      parseInt(dashboardID),
                      parseInt(alertDestinationID),
                      subject,
                      message,
                      url,
                      custom1,
                      custom2,
                      status
                    );
                    console.log(response);
                    rl.close();
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});
