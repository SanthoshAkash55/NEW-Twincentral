const { getAlert } = require("../TwinCentralAPI");

getAlert()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
