const { getAlertbySendAlert } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("alertDateTime: ", async (alertDateTime) => {
  rl.question("dashboardID: ", async (dashboardID) => {
    rl.question("alertDestinationID: ", async (alertDestinationID) => {
      rl.question("subject: ", async (subject) => {
        rl.question("message: ", async (message) => {
          rl.question("url: ", async (url) => {
            rl.question("custom1: ", async (custom1) => {
              rl.question("custom2: ", async (custom2) => {
                const response = await getAlertbySendAlert(
                  alertDateTime,
                  parseInt(dashboardID),
                  parseInt(alertDestinationID),
                  subject,
                  message,
                  url,
                  custom1,
                  custom2
                );
                console.log(response);
                rl.close();
              });
            });
          });
        });
      });
    });
  });
});
