const { deleteDashboardRolebydashboardId } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("dashboardId : ", async (dashboardId) => {
  rl.question("roleId: ", async (roleId) => {
    const response = await deleteDashboardRolebydashboardId(
      dashboardId,
      roleId
    );
    console.log(response);
    rl.close();
  });
});
