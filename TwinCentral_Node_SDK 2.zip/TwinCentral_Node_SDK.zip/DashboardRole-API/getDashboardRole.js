const { getDashboardRole } = require("../TwinCentralAPI");

getDashboardRole()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
