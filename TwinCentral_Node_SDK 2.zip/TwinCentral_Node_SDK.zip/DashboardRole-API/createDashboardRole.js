const { createDashboardRole } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("dashboardId: ", async (dashboardId) => {
  rl.question("roleId: ", async (roleId) => {
    rl.question("Is Active? (true/false): ", async (isActive) => {
      const response = await createDashboardRole(dashboardId, roleId, isActive);
      console.log(response);
      rl.close();
    });
  });
});
