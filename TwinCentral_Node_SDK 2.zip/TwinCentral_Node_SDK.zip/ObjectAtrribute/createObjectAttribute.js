const { createObjectAttribute } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create ObjectAttribute *************");
rl.question("id: ", async (id) => {
  rl.question("ObjectID: ", async (ObjectID) => {
    rl.question("attributeID: ", async (attributeID) => {
      rl.question("value: ", async (value) => {
        rl.question("activatedOn: ", async (activatedOn) => {
          rl.question("deactivatedOn: ", async (deactivatedOn) => {
            rl.question("Is Active? (true/false): ", async (isActive) => {
              // Create an object with the entered data
              const response = await createObjectAttribute(
                parseInt(id),
                parseInt(ObjectID),
                parseInt(attributeID),
                value,
                activatedOn,
                deactivatedOn,
                isActive
              );
              console.log(response);
              rl.close();
            });
          });
        });
      });
    });
  });
});
