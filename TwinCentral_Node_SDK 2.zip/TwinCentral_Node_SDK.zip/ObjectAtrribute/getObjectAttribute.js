const { getObjectAttribute } = require("../TwinCentralAPI");

getObjectAttribute()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
