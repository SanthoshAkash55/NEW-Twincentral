const { getGraphbyroleId } = require("../TwinCentralAPI");

const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("# What's the roleId ?", async (roleId) => {
  //   console.log(Id, "Id");

  const response = await getGraphbyroleId(parseInt(roleId));
  console.log(response);
  console.log(
    "#################################################################################"
  );
  rl.close();
});
