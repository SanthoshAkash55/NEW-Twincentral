const { getGraph } = require("../TwinCentralAPI");

getGraph()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
