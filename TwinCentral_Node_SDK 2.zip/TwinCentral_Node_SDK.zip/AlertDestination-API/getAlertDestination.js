const { getAlertDestination } = require("../TwinCentralAPI");

getAlertDestination()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
