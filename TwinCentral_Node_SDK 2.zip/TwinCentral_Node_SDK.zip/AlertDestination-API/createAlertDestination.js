const { createAlertDestination } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("id: ", async (id) => {
  rl.question("host: ", async (host) => {
    rl.question("url: ", async (url) => {
      rl.question("port: ", async (port) => {
        rl.question("protocol: ", async (protocol) => {
          rl.question(
            "alertDestinationType: ",
            async (alertDestinationType) => {
              rl.question("authentication: ", async (authentication) => {
                rl.question("custom1: ", async (custom1) => {
                  rl.question("custom2: ", async (custom2) => {
                    // Create an object with the entered data
                    const response = await createAlertDestination(
                      parseInt(id),
                      host,
                      url,
                      port,
                      protocol,
                      alertDestinationType,
                      authentication,
                      custom1,
                      custom2
                    );
                    console.log(response);
                    rl.close();
                  });
                });
              });
            }
          );
        });
      });
    });
  });
});
