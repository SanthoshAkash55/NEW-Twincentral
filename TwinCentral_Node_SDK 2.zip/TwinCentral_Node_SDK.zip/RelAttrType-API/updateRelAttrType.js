const { updateRelAttrType } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("id: ", async (id) => {
    rl.question("name: ", async (name) => {
      rl.question("description: ", async (description) => {
        rl.question("category: ", async (category) => {
          rl.question("activatedOn: ", async (activatedOn) => {
            rl.question("deactivatedOn: ", async (deactivatedOn) => {
              rl.question("Is Active? (true/false): ", async (isActive) => {
                // Create an object with the entered data
                const response = await updateRelAttrType(
                  Id,
                  parseInt(id),
                  name,
                  description,
                  category,
                  activatedOn,
                  deactivatedOn,
                  isActive
                );
                console.log(response);
                rl.close();
              });
            });
          });
        });
      });
    });
  });
});
