const { getRelAttrType } = require("../TwinCentralAPI");

getRelAttrType()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
