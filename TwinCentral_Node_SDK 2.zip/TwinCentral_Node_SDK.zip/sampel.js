const readline = require("readline");
const fs = require("fs");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Enter the file path: ", (filePath) => {
  // Read the file contents
  fs.readFile(filePath, (err, data) => {
    // console.log(data);
    const fileContent = data.toString();

    // Display the file contents
    console.log("File contents:");
    console.log(fileContent);
    if (err) {
      console.error("Error reading file:", err);
      rl.close();
      return;
    }

    // Perform file upload logic here
    // For example, you can make an API request to upload the file
    // or save it to a storage service like AWS S3

    console.log("File uploaded successfully!");
    rl.close();
  });
});
