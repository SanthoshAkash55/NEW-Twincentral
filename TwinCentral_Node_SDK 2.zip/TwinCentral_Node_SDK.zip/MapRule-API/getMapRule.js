const { getMapRule } = require("../TwinCentralAPI");

getMapRule()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
