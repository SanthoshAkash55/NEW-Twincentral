const { updateMapRule } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("graphMapId: ", async (graphMapId) => {
    rl.question("nodeLevel: ", async (nodeLevel) => {
      rl.question("fieldName: ", async (fieldName) => {
        rl.question("extractionRegExp: ", async (extractionRegExp) => {
          rl.question("aliasDictiornary: ", async (aliasDictiornary) => {
            rl.question("augmentationString: ", async (augmentationString) => {
              rl.question("propertyList: ", async (propertyList) => {
                rl.question("attributeList: ", async (attributeList) => {
                  rl.question(
                    "timeSeriesPointList: ",
                    async (timeSeriesPointList) => {
                      rl.question(
                        "Is Active? (true/false): ",
                        async (isActive) => {
                          // Create an object with the entered data
                          const response = await updateMapRule(
                            Id,
                            parseInt(graphMapId),
                            nodeLevel,
                            fieldName,
                            extractionRegExp,
                            aliasDictiornary,
                            augmentationString,
                            propertyList,
                            attributeList,
                            timeSeriesPointList,
                            isActive
                          );
                          console.log(response);
                          rl.close();
                        }
                      );
                    }
                  );
                });
              });
            });
          });
        });
      });
    });
  });
});
