const { updateOrganization } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("name: ", async (name) => {
    rl.question("description: ", async (description) => {
      rl.question("contactInfo: ", async (contactInfo) => {
        rl.question("Is Active? (true/false): ", async (isActive) => {
          const response = await updateOrganization(
            Id,
            name,
            description,
            contactInfo,
            isActive
          );
          console.log(response);
          rl.close();
        });
      });
    });
  });
});
