const { getOrganization } = require("../TwinCentralAPI");

getOrganization()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
