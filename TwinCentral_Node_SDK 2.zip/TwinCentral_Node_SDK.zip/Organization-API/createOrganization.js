const { createOrganization } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("name: ", async (name) => {
  rl.question("description: ", async (description) => {
    rl.question("contactInfo: ", async (contactInfo) => {
      rl.question("Is Active? (true/false): ", async (isActive) => {
        const response = await createOrganization(
          name,
          description,
          contactInfo,
          isActive
        );
        console.log(response);
        rl.close();
      });
    });
  });
});
