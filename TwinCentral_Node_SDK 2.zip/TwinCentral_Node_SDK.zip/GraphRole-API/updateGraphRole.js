const { updateGraphRole } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("graphId: ", async (graphId) => {
    rl.question("roleId: ", async (roleId) => {
      rl.question("Is Active? (true/false): ", async (isActive) => {
        const response = await updateGraphRole(Id, graphId, roleId, isActive);
        console.log(response);
        rl.close();
      });
    });
  });
});
