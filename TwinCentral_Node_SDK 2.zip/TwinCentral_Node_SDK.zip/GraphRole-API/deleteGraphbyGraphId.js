const { deleteGraphbygraphId } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("GraphId : ", async (GraphId) => {
  rl.question("roleId: ", async (roleId) => {
    const response = await deleteGraphbygraphId(GraphId, roleId);
    console.log(response);
    rl.close();
  });
});
