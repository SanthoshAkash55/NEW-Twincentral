const { createGraphrole } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create GraphRole *************");
rl.question("graphId: ", async (graphId) => {
  rl.question("roleId: ", async (roleId) => {
    rl.question("Is Active? (true/false): ", async (isActive) => {
      const response = await createGraphrole(graphId, roleId, isActive);
      console.log(response);
      rl.close();
    });
  });
});
