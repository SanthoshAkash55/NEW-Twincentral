const { getUserbyEmail } = require("../TwinCentralAPI");

const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("# What's the Email Address?", async (EmailAddress) => {
  const response = await getUserbyEmail(EmailAddress);
  console.log(response);
  console.log(
    "#################################################################################"
  );
  rl.close();
});
