const { getAllUser } = require("../TwinCentralAPI");

getAllUser()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
