const { createUser } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create User *************");
rl.question("First Name: ", async (firstName) => {
  rl.question("Last Name: ", async (lastName) => {
    rl.question("Email Address: ", async (emailAddress) => {
      rl.question("Phone Number: ", async (phoneNumber) => {
        rl.question("Organization ID: ", async (organizationId) => {
          rl.question("Password: ", async (password) => {
            rl.question("Is Active? (true/false): ", async (isActive) => {
              // Create an object with the entered data
              const response = await createUser(
                firstName,
                lastName,
                emailAddress,
                phoneNumber,
                organizationId,
                password,
                isActive
              );
              console.log(response);
              rl.close();
            });
          });
        });
      });
    });
  });
});
