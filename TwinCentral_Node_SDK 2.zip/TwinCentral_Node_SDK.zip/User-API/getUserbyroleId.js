const { getUserbyroleId } = require("../TwinCentralAPI");

const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("# What's the roleId ?", async (roleId) => {
  const response = await getUserbyroleId(parseInt(roleId));
  console.log(response);
  console.log(
    "#################################################################################"
  );
  rl.close();
});
