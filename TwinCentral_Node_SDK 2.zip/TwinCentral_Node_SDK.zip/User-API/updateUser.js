const { updateUser } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("First Name: ", async (firstName) => {
    rl.question("Last Name: ", async (lastName) => {
      rl.question("Email Address: ", async (emailAddress) => {
        rl.question("Phone Number: ", async (phoneNumber) => {
          rl.question("Organization ID: ", async (organizationId) => {
            rl.question("updatedBy: ", async (updatedBy) => {
              rl.question("Is Active? (true/false): ", async (isActive) => {
                // Create an object with the entered data
                const response = await updateUser(
                  Id,
                  firstName,
                  lastName,
                  emailAddress,
                  phoneNumber,
                  organizationId,
                  updatedBy,
                  isActive
                );
                console.log(response);
                rl.close();
              });
            });
          });
        });
      });
    });
  });
});
