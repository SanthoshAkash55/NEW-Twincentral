const { resetUserPassword } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Old Password: ", async (oldPassword) => {
  rl.question("New Password: ", async (newPassword) => {
    rl.question("Email Address: ", async (emailAddress) => {
      const response = await resetUserPassword(
        oldPassword,
        newPassword,
        emailAddress
      );
      console.log(response);
      rl.close();
    });
  });
});
