const { getObjectRelationshipObject } = require("../TwinCentralAPI");

getObjectRelationshipObject()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
