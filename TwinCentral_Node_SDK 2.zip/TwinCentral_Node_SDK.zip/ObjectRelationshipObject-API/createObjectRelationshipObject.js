const { createObjectRelationshipObject } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create ObjectRelationshipObject *************");
rl.question("id: ", async (id) => {
  rl.question("objectID11: ", async (objectID1) => {
    rl.question("relationshipID: ", async (relationshipID) => {
      rl.question("objectID2: ", async (objectID2) => {
        rl.question("activatedOn: ", async (activatedOn) => {
          rl.question("deactivatedOn: ", async (deactivatedOn) => {
            rl.question("Is Active? (true/false): ", async (isActive) => {
              // Create an object with the entered data
              const response = await createObjectRelationshipObject(
                parseInt(id),
                parseInt(objectID1),
                parseInt(relationshipID),
                objectID2,
                activatedOn,
                deactivatedOn,
                isActive
              );
              console.log(response);
              rl.close();
            });
          });
        });
      });
    });
  });
});
