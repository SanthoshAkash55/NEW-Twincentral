const { createUserRole } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("userId: ", async (userId) => {
  rl.question("roleId: ", async (roleId) => {
    rl.question("Is Active? (true/false): ", async (isActive) => {
      const response = await createUserRole(userId, roleId, isActive);
      console.log(response);
      rl.close();
    });
  });
});
