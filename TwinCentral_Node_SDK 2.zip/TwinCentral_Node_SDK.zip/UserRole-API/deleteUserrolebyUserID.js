const { deleteUserRolebyUserId } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("userId: ", async (userId) => {
  rl.question("roleId: ", async (roleId) => {
    const response = await deleteUserRolebyUserId(
      parseInt(userId),
      parseInt(roleId)
    );
    console.log(response);
    rl.close();
  });
});
