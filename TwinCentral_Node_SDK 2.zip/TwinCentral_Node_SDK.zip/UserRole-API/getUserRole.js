const { getUserRole } = require("../TwinCentralAPI");

getUserRole()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
