const { getDatasource } = require("../TwinCentralAPI");

getDatasource()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
