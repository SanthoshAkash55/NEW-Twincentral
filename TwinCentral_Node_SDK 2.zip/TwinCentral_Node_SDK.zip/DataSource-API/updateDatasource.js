const { updateDatasource } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create Datasource *************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("id: ", async (id) => {
    rl.question("name: ", async (name) => {
      rl.question("shortName: ", async (shortName) => {
        rl.question("description: ", async (description) => {
          rl.question("typeID: ", async (typeID) => {
            rl.question("info: ", async (info) => {
              rl.question("hostName: ", async (hostName) => {
                rl.question("pathName: ", async (pathName) => {
                  rl.question("protocol: ", async (protocol) => {
                    rl.question("port: ", async (port) => {
                      rl.question("bucketName: ", async (bucketName) => {
                        rl.question("folderName: ", async (folderName) => {
                          rl.question("fileName: ", async (fileName) => {
                            rl.question(
                              "connectString1: ",
                              async (connectString1) => {
                                rl.question(
                                  "connectString2: ",
                                  async (connectString2) => {
                                    rl.question(
                                      "accessKey: ",
                                      async (accessKey) => {
                                        rl.question(
                                          "accessSecret: ",
                                          async (accessSecret) => {
                                            rl.question(
                                              "authToken: ",
                                              async (authToken) => {
                                                rl.question(
                                                  "databaseName: ",
                                                  async (databaseName) => {
                                                    rl.question(
                                                      "tableName: ",
                                                      async (tableName) => {
                                                        rl.question(
                                                          "selectString: ",
                                                          async (
                                                            selectString
                                                          ) => {
                                                            rl.question(
                                                              "customString: ",
                                                              async (
                                                                customString
                                                              ) => {
                                                                rl.question(
                                                                  "activatedOn: ",
                                                                  async (
                                                                    activatedOn
                                                                  ) => {
                                                                    rl.question(
                                                                      "deactivatedOn: ",
                                                                      async (
                                                                        deactivatedOn
                                                                      ) => {
                                                                        rl.question(
                                                                          "Is Active? (true/false): ",
                                                                          async (
                                                                            isActive
                                                                          ) => {
                                                                            // Create an object with the entered data
                                                                            const response =
                                                                              await updateDatasource(
                                                                                Id,
                                                                                id,
                                                                                name,
                                                                                shortName,
                                                                                description,
                                                                                typeID,
                                                                                info,
                                                                                hostName,
                                                                                pathName,
                                                                                protocol,
                                                                                port,
                                                                                bucketName,
                                                                                folderName,
                                                                                fileName,
                                                                                connectString1,
                                                                                connectString2,
                                                                                accessKey,
                                                                                accessSecret,
                                                                                authToken,
                                                                                databaseName,
                                                                                tableName,
                                                                                selectString,
                                                                                customString,
                                                                                activatedOn,
                                                                                deactivatedOn,
                                                                                isActive
                                                                              );
                                                                            console.log(
                                                                              response
                                                                            );
                                                                            rl.close();
                                                                          }
                                                                        );
                                                                      }
                                                                    );
                                                                  }
                                                                );
                                                              }
                                                            );
                                                          }
                                                        );
                                                      }
                                                    );
                                                  }
                                                );
                                              }
                                            );
                                          }
                                        );
                                      }
                                    );
                                  }
                                );
                              }
                            );
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});
