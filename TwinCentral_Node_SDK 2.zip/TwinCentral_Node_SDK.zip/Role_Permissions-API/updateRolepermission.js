const { updateRolepermission } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("roleId: ", async (roleId) => {
    rl.question("permissionId: ", async (permissionId) => {
      rl.question("Is Active? (true/false): ", async (isActive) => {
        const response = await updateRolepermission(
          Id,
          roleId,
          permissionId,
          isActive
        );
        console.log(response);
        rl.close();
      });
    });
  });
});
