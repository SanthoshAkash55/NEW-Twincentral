const { createRolepermission } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("roleId: ", async (roleId) => {
  rl.question("permissionId: ", async (permissionId) => {
    rl.question("Is Active? (true/false): ", async (isActive) => {
      const response = await createRolepermission(
        roleId,
        permissionId,
        isActive
      );
      console.log(response);
      rl.close();
    });
  });
});
