const { createruleEnginetreebyS3Csv } = require("../TwinCentralAPI");
const readline = require("readline");
const fs = require("fs");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("dataSourceId: ", async (dataSourceId) => {
  rl.question("graphMapId: ", async (graphMapId) => {
    rl.question("treeName: ", async (treeName) => {
      const response = await createruleEnginetreebyS3Csv(
        dataSourceId,
        graphMapId,
        treeName
      );
      console.log(response);
      rl.close();
    });
  });
});
