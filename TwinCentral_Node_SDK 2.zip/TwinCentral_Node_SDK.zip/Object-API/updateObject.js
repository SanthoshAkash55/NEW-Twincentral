const { updateObject } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("id: ", async (id) => {
    rl.question("uidig: ", async (uidig) => {
      rl.question("name: ", async (name) => {
        rl.question("description: ", async (description) => {
          rl.question("graphID: ", async (graphID) => {
            rl.question("typeID: ", async (typeID) => {
              rl.question("activatedOn: ", async (activatedOn) => {
                rl.question("deactivatedOn: ", async (deactivatedOn) => {
                  rl.question("isActive? (true/false): ", async (isActive) => {
                    const response = await updateObject(
                      Id,
                      id,
                      uidig,
                      name,
                      description,
                      graphID,
                      typeID,
                      activatedOn,
                      deactivatedOn,
                      isActive
                    );
                    console.log(response);
                    rl.close();
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});
