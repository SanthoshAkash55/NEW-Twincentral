const { getObjectList } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Ids: ", async (Ids) => {
  rl.question("Names: ", async (Names) => {
    rl.question("Requesting: ", async (Requesting) => {
        const response = await getObjectList(
          Ids,
          Names,
          Requesting,
        );
        console.log(response);
        rl.close();
      });
    });
  });
