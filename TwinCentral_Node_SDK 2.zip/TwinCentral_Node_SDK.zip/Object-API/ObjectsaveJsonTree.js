const { ObjectbyJsonTree } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("enter the value: ", async (value) => {
  // Process the collected data as needed
  const response = await ObjectbyJsonTree(value);
  console.log(response);
  rl.close();
});
