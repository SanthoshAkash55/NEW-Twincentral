const { getObjectMatch } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Ids: ", async (Id) => {
  rl.question("Names: ", async (Name) => {
    rl.question("Requesting: ", async (RelationshipId) => {
      rl.question("Requesting: ", async (RelationshipName) => {
        rl.question("Requesting: ", async (Requesting) => {
          const response = await getObjectMatch(
            Id,
            Name,
            RelationshipId,
            RelationshipName,
            Requesting
          );
          console.log(response);
          rl.close();
        });
      });
    });
  });
});
