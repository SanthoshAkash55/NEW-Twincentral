const { createObject } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("id: ", async (id) => {
  rl.question("uidig: ", async (uidig) => {
    rl.question("name: ", async (name) => {
      rl.question("description: ", async (description) => {
        rl.question("graphID: ", async (graphID) => {
          rl.question("typeID: ", async (typeID) => {
            rl.question("activatedOn: ", async (activatedOn) => {
              rl.question("deactivatedOn: ", async (deactivatedOn) => {
                rl.question("isActive? (true/false): ", async (isActive) => {
                  const response = await createObject(
                    id,
                    uidig,
                    name,
                    description,
                    graphID,
                    typeID,
                    activatedOn,
                    deactivatedOn,
                    isActive
                  );
                  console.log(response);
                  rl.close();
                });
              });
            });
          });
        });
      });
    });
  });
});
