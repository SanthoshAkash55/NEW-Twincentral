const { getObjectbyquery } = require("../TwinCentralAPI");

const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
// exports.getModelquery = async (req, res) => {
//     console.log(req.query,"rqrqrq")
//     const query = req.query.query
//   try {
//     const response = await getModelbyQuery(query); // get the modelName
//     // handle the request with the model here
//     res.send(response);
//   } catch (error) {
//     console.log(error, "err");
//     res.status(500).send("Error loading the model");
//   }
// };

rl.question("query ?", async (query) => {
  const data = await getObjectbyquery(query);
  console.log(data);
  console.log(
    "#################################################################################"
  );
  rl.close();
});
