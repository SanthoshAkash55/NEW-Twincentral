const { getRole } = require("../TwinCentralAPI");

getRole()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
