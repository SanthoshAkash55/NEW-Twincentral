const { createRole } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("roleName: ", async (roleName) => {
  rl.question("description: ", async (description) => {
    rl.question("Is Active? (true/false): ", async (isActive) => {
      const response = await createRole(roleName, description, isActive);
      console.log(response);
      rl.close();
    });
  });
});
