const { createRelationshipDef } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Create RelationshipAttribute *************");
rl.question("id: ", async (id) => {
  rl.question("name: ", async (name) => {
    rl.question("description: ", async (description) => {
      rl.question("typeID: ", async (typeID) => {
        rl.question("activatedOn: ", async (activatedOn) => {
          rl.question("deactivatedOn: ", async (deactivatedOn) => {
            rl.question("Is Active? (true/false): ", async (isActive) => {
              // Create an object with the entered data
              const response = await createRelationshipDef(
                parseInt(id),
                name,
                description,
                parseInt(typeID),
                activatedOn,
                deactivatedOn,
                isActive
              );
              console.log(response);
              rl.close();
            });
          });
        });
      });
    });
  });
});
