const { getRelationshipDef } = require("../TwinCentralAPI");

getRelationshipDef()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
