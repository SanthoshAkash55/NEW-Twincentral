const { getAssetTree } = require("../TwinCentralAPI");

getAssetTree()
  .then((response) => {
    const children = response[0];
    console.log(children);
  })
  .catch((error) => console.error(error));
