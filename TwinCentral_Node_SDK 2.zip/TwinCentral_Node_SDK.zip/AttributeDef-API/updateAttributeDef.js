const { updateAttributeDef } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Enter your Id : ", async (Id) => {
  rl.question("id: ", async (id) => {
    rl.question("name: ", async (name) => {
      rl.question("description: ", async (description) => {
        rl.question("extraInfo: ", async (extraInfo) => {
          rl.question("typeID: ", async (typeID) => {
            rl.question("activatedOn: ", async (activatedOn) => {
              rl.question("deactivatedOn: ", async (deactivatedOn) => {
                rl.question("Is Active? (true/false): ", async (isActive) => {
                  const response = await updateAttributeDef(
                    Id,
                    id,
                    name,
                    description,
                    extraInfo,
                    typeID,
                    activatedOn,
                    deactivatedOn,
                    isActive
                  );
                  console.log(response);
                  rl.close();
                });
              });
            });
          });
        });
      });
    });
  });
});
