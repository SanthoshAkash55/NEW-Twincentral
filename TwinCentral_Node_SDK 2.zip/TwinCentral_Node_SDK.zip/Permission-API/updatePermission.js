const { updatePermission } = require("../TwinCentralAPI");
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
console.log("********* Update the User ***************");
rl.question("Enter your Id : ", async (Id) => {
  rl.question("permissionName: ", async (permissionName) => {
    rl.question("description: ", async (description) => {
      rl.question("Is Active? (true/false): ", async (isActive) => {
        const response = await updatePermission(
          Id,
          permissionName,
          description,
          isActive
        );
        console.log(response);
        rl.close();
      });
    });
  });
});
