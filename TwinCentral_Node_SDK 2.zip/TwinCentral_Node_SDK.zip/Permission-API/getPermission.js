const { getPermission } = require("../TwinCentralAPI");

getPermission()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
