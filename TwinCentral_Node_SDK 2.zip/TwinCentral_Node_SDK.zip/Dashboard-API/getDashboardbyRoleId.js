const { getDashboardbyroleId } = require("../TwinCentralAPI");

const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("# What's the roleId ?", async (roleId) => {
  const response = await getDashboardbyroleId(parseInt(roleId));
  console.log(response);
  console.log(
    "#################################################################################"
  );
  rl.close();
});
