const { getDashboard } = require("../TwinCentralAPI");

getDashboard()
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
