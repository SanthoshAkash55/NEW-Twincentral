const axios = require("axios");
const https = require("https");
require("dotenv").config();
const redis = require("redis");
// const REDIS_PORT = 6379;
const client = redis.createClient();
client.connect();

const eotGatewayUrl = "https://107.22.3.238/eot";
const eotHeaders = {
  "content-type": "application/json",
  Authorization:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEiLCJuYmYiOjE2ODg1NjU2NjYsImV4cCI6MTY4ODY1MjA2NiwiaWF0IjoxNjg4NTY1NjY2fQ.znxmv69l65rTYth9ZLSHJAp6n1qpaEk2H_Ro9nXG7nY",
};

// const client = redis.createClient();

exports.authentication = async (EmailAddress, password) => {
  // console.log(EmailAddress, password, "EmailAddress,password");
  try {
    const payload = {
      EmailAddress: EmailAddress,
      password: password,
    };
    const config = {
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
      // headers: {
      //   Authorization: `Bearer ${authToken}`, // Include the token as a header
      // },
    };
    const response = await axios.post(
      `${eotGatewayUrl}/user/authenticate`,
      payload,
      config
    );
    const userDetails = response.data;
    await client.set(`userDetails`, JSON.stringify(userDetails));

    // let connectionInfo = JSON.parse(await client.get("userDetails"));
    // console.log("!!!", connectionInfo.token);

    client.quit();
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

//// User-API

exports.getUserbyId = async (Id) => {
  try {
    let userDetails = JSON.parse(await client.get("userDetails"));
    const authToken = userDetails.token;
    const config = {
      headers: eotHeaders,
      headers: {
        Authorization: authToken, // Include the token as a header
      },
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/User/${Id}`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getUserbyEmail = async (Email) => {
  console.log(Email, "Email");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/User/GetByEmail/${Email}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getAllUser = async () => {
  try {
    let userDetails = JSON.parse(await client.get("userDetails"));
    const authToken = userDetails.token;
    const config = {
      headers: eotHeaders,
      headers: {
        Authorization: authToken, // Include the token as a header
      },
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/User`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.createUser = async (
  firstName,
  lastName,
  emailAddress,
  phoneNumber,
  organizationId,
  password,
  isActive
) => {
  try {
    const payload = {
      firstName,
      lastName,
      emailAddress,
      phoneNumber,
      organizationId: parseInt(organizationId),
      password,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(`${eotGatewayUrl}/User`, payload, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response, "err in model");
  }
};

exports.updateUser = async (
  Id,
  firstName,
  lastName,
  emailAddress,
  phoneNumber,
  organizationId,
  updatedBy,
  isActive
) => {
  try {
    const payload = {
      firstName,
      lastName,
      emailAddress,
      phoneNumber,
      organizationId: parseInt(organizationId),
      updatedBy,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/User?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.deleteUser = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/User?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.getUserbyroleId = async (roleId) => {
  console.log(roleId, "roleId");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/User/roleId?roleId=${roleId}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.resetUserPassword = async (oldPassword, newPassword, emailAddress) => {
  try {
    const payload = {
      oldPassword,
      newPassword,
      emailAddress,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/User/resetpassword`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

////User_role-API

exports.getUserRole = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/UserRole`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getUserRolebyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/UserRole/${Id}`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.createUserRole = async (userId, roleId, isActive) => {
  try {
    const payload = {
      userId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/UserRole`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.updateUserRole = async (Id, userId, roleId, isActive) => {
  try {
    const payload = {
      userId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/UserRole?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.deleteUserRole = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/UserRole?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.deleteUserRolebyUserId = async (userId, roleId) => {
  console.log(userId, roleId);
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/UserRole/DeleteByUserId?userId=${userId}&roleId=${roleId}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

///Role-API

exports.getRole = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Role`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getRolebyId = async (Id) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Role/${Id}`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.createRole = async (roleName, description, isActive) => {
  try {
    const payload = {
      roleName,
      description,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(`${eotGatewayUrl}/Role`, payload, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.updateRole = async (Id, roleName, description, isActive) => {
  try {
    const payload = {
      roleName,
      description,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Role?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.deleteRole = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Role?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

//// Role_permissions-API

exports.getRolepermissions = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/RolePermission`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getRolepermissionbyId = async (Id) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RolePermission/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.createRolepermission = async (roleId, permissionId, isActive) => {
  try {
    const payload = {
      roleId,
      permissionId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/RolePermission`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.updateRolepermission = async (Id, roleId, permissionId, isActive) => {
  try {
    const payload = {
      roleId,
      permissionId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/RolePermission?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.deleteRolepermission = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/RolePermission?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

//// Model-API

exports.getModel = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/model/tree`, config);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response, "err in model");
  }
};

exports.getModelByName = async (modelName) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Model/modelByName/${modelName}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelByName");
  }
};

exports.getModelbyassetid = async (assetModelId) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Model/children/${assetModelId}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getModels = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Model/Models`, config);
    // console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in models");
  }
};

exports.getModelId = async (Id) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Model/${Id}`, config);
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getModelbyQuery = async (Name = "", AttributeName = "") => {
  // console.log("getModelbyQuery", Name, AttributeName);
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Model/query?Name=${Name}&AttributeName=${AttributeName}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in getModelbyassetid");
  }
};

///// RelAttrType - API

exports.getRelAttrType = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/RelAttrType`, config);
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelAttrType");
    return error.response?.data;
  }
};

exports.getRelAttrTypebyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RelAttrType/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createRelAttrType = async (
  id,
  name,
  description,
  category,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      category,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/RelAttrType`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateRelAttrType = async (
  Id,
  id,
  name,
  description,
  category,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      category,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/RelAttrType?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteRelAttrType = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/RelAttrType?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

//// Relationship-def

exports.getRelationshipDef = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RelationshipDef`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getRelationshipDefbyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RelationshipDef/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createRelationshipDef = async (
  id,
  name,
  description,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      typeID,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/RelationshipDef`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateRelationshipDef = async (
  Id,
  id,
  name,
  description,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      typeID: parseInt(typeID),
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/RelationshipDef?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteRelationshipDef = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/RelationshipDef?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

//// RelationshipAttribute - API

exports.getRelationshipAttribute = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RelationshipAttribute`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getRelationshipAttributebyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/RelationshipAttribute/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createRelationshipAttribute = async (
  id,
  objectRelationshipObjectID,
  attributeID,
  value,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      objectRelationshipObjectID: parseInt(objectRelationshipObjectID),
      attributeID: parseInt(attributeID),
      value,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/RelationshipAttribute`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateRelationshipAttribute = async (
  Id,
  id,
  objectRelationshipObjectID,
  attributeID,
  value,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      objectRelationshipObjectID: parseInt(objectRelationshipObjectID),
      attributeID: parseInt(attributeID),
      value,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/RelationshipAttribute?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteRelationshipAttribute = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/RelationshipAttribute?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Permission-API

exports.getPermission = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Permission`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getPermissionbyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Permission/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createPermissions = async (permissionName, description, isActive) => {
  try {
    const payload = {
      permissionName,
      description,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Permissions`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updatePermission = async (
  Id,
  permissionName,
  description,
  isActive
) => {
  try {
    const payload = {
      Id,
      permissionName,
      description,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Permissions?id=${id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deletePermission = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Permissions?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Organization-API

exports.getOrganization = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Organization`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getOrganizationbyId = async (Id) => {
  console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Organization/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createOrganization = async (
  name,
  description,
  contactInfo,
  isActive
) => {
  try {
    const payload = {
      name,
      description,
      contactInfo,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Organization`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateOrganization = async (
  Id,
  name,
  description,
  contactInfo,
  isActive
) => {
  try {
    const payload = {
      name,
      description,
      contactInfo,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Organization?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteOrganization = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Organization?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// MapRule - API

exports.getMapRule = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/MapRule`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getMapRulebyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/MapRule/${Id}`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createMapRule = async (
  graphMapId,
  nodeLevel,
  fieldName,
  extractionRegExp,
  aliasDictiornary,
  augmentationString,
  propertyList,
  attributeList,
  timeSeriesPointList,
  isActive
) => {
  try {
    const payload = {
      graphMapId,
      nodeLevel,
      fieldName,
      extractionRegExp,
      aliasDictiornary,
      augmentationString,
      propertyList,
      attributeList,
      timeSeriesPointList,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/MapRule`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateMapRule = async (
  Id,
  graphMapId,
  nodeLevel,
  fieldName,
  extractionRegExp,
  aliasDictiornary,
  augmentationString,
  propertyList,
  attributeList,
  timeSeriesPointList,
  isActive
) => {
  try {
    const payload = {
      graphMapId,
      nodeLevel,
      fieldName,
      extractionRegExp,
      aliasDictiornary,
      augmentationString,
      propertyList,
      attributeList,
      timeSeriesPointList,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/MapRule?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteMapRule = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/MapRule?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

/// GraphRole - API

exports.getGraphRole = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/GraphRole`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getGrapghrolebyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/GraphRole/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createGraphRole = async (graphId, roleId, isActive) => {
  try {
    const payload = {
      graphId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/GraphRole`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateGraphRole = async (Id, graphId, roleId, isActive) => {
  try {
    const payload = {
      Id,
      graphId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/GraphRole?id=${id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteGraphrole = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/GraphRole?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.deleteGraphbygraphId = async (GraphId, roleId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/GraphRole/DeleteByGraphId?graphId=${GraphId}&roleId=${roleId}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.getGraphRolebyUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/GraphRole/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

//// GraphMap - API

exports.getGraphMap = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/GraphMap`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getGrapghMapbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/GraphMap/${Id}`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createGraphMap = async (
  id,
  name,
  description,
  typeID,
  datasourceID,
  selectString,
  attributeList,
  createdBy,
  createdOn,
  updatedBy,
  updatedOn,
  isActive,
  rowVersion
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      description,
      typeID: parseInt(typeID),
      datasourceID: parseInt(datasourceID),
      selectString,
      attributeList,
      createdBy,
      createdOn,
      updatedBy,
      updatedOn,
      isActive: isActive.toLowerCase() === "true",
      rowVersion,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/GraphMap`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateGraphMap = async (
  Id,
  id,
  name,
  description,
  typeID,
  datasourceID,
  selectString,
  attributeList,
  createdBy,
  createdOn,
  updatedBy,
  updatedOn,
  isActive,
  rowVersion
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      description,
      typeID: parseInt(typeID),
      datasourceID: parseInt(datasourceID),
      selectString,
      attributeList,
      createdBy,
      createdOn,
      updatedBy,
      updatedOn,
      isActive: isActive.toLowerCase() === "true",
      rowVersion,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/GraphMap?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteGraphMap = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/GraphMap?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.getGraphMapbyUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/GraphMap/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

/// Graph - API

exports.getGraph = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Graph`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getGraphbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Graph/${Id}`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createGraph = async (
  id,
  name,
  description,
  userID,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      description,
      userID: parseInt(userID),
      typeID: parseInt(typeID),
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Graph`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateGraph = async (
  Id,
  id,
  name,
  description,
  userID,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      description,
      userID: parseInt(userID),
      typeID: parseInt(typeID),
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Graph?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteGraph = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Graph?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

// getGraphbyUserId;

exports.getGraphbyUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Graph/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getGraphbyroleId = async (roleId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Graph/list?roleId=${roleId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

//// DataSource-API

exports.getDatasource = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Datasource`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getDatasourcebyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Datasource/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createDatasource = async (
  id,
  name,
  shortName,
  description,
  typeID,
  info,
  hostName,
  pathName,
  protocol,
  port,
  bucketName,
  folderName,
  fileName,
  connectString1,
  connectString2,
  accessKey,
  accessSecret,
  authToken,
  databaseName,
  tableName,
  selectString,
  customString,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      shortName,
      description,
      typeID: parseInt(typeID),
      info,
      hostName,
      pathName,
      protocol,
      port: parseInt(port),
      bucketName,
      folderName,
      fileName,
      connectString1,
      connectString2,
      accessKey,
      accessSecret,
      authToken,
      databaseName,
      tableName,
      selectString,
      customString,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Datasource`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateDatasource = async (
  Id,
  id,
  name,
  shortName,
  description,
  typeID,
  info,
  hostName,
  pathName,
  protocol,
  port,
  bucketName,
  folderName,
  fileName,
  connectString1,
  connectString2,
  accessKey,
  accessSecret,
  authToken,
  databaseName,
  tableName,
  selectString,
  customString,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id: parseInt(id),
      name,
      shortName,
      description,
      typeID: parseInt(typeID),
      info,
      hostName,
      pathName,
      protocol,
      port: parseInt(port),
      bucketName,
      folderName,
      fileName,
      connectString1,
      connectString2,
      accessKey,
      accessSecret,
      authToken,
      databaseName,
      tableName,
      selectString,
      customString,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Datasource?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteDatasource = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Datasource?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.getDatasourcebyUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Datasource/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

//// DashboardRole - API

exports.getDashboardRole = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/DashboardRole`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getDashboardrolebyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/DashboardRole/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createDashboardRole = async (dashboardId, roleId, isActive) => {
  try {
    const payload = {
      dashboardId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/DashboardRole`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateDashboardRole = async (Id, dashboardId, roleId, isActive) => {
  try {
    const payload = {
      dashboardId,
      roleId,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/DashboardRole?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getDashboardRoleUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/DashboardRole/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteDashboardRole = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/DashboardRole?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.deleteDashboardRolebydashboardId = async (dashboardId, roleId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/DashboardRole/DeleteByDashboardId?dashboardId=${dashboardId}&roleId=${roleId}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

///Dashboard - API

exports.getDashboard = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Dashboard`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getDashboardbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Dashboard/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createDashboard = async (
  id,
  name,
  description,
  userID,
  typeID,
  dashboardJSON,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      userID,
      typeID,
      dashboardJSON,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Dashboard`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateDashboard = async (
  Id,
  id,
  name,
  description,
  userID,
  typeID,
  dashboardJSON,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      userID,
      typeID,
      dashboardJSON,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Dashboard?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getDashboardUserId = async (UserId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Dashboard/list?userId=${UserId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getDashboardbyroleId = async (roleId) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Dashboard/roleId?roleId=${roleId}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteDashboard = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Dashboard?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Attribute-API

exports.getAttributeDef = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/AttributeDef`, config);
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getAttributeDefbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/AttributeDef/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createAttributeDef = async (
  id,
  name,
  description,
  extraInfo,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      name,
      description,
      extraInfo,
      typeID,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/AttributeDef`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateAttributeDef = async (
  Id,
  id,
  name,
  description,
  extraInfo,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      Id,
      id,
      name,
      description,
      extraInfo,
      typeID,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/AttributeDef?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteAttributeDef = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/AttributeDef?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// AlertDestination-API

exports.getAlertDestination = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/AlertDestination`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getAlertDestinationbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/AlertDestination/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createAlertDestination = async (
  id,
  host,
  url,
  port,
  protocol,
  alertDestinationType,
  authentication,
  custom1,
  custom2
) => {
  try {
    const payload = {
      id: parseInt(id),
      host,
      url,
      port: parseInt(port),
      protocol,
      alertDestinationType,
      authentication,
      custom1,
      custom2,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/AlertDestination`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateAlertDestination = async (
  Id,
  id,
  host,
  url,
  port,
  protocol,
  alertDestinationType,
  authentication,
  custom1,
  custom2
) => {
  try {
    const payload = {
      id: parseInt(id),
      host,
      url,
      port: parseInt(port),
      protocol,
      alertDestinationType,
      authentication,
      custom1,
      custom2,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/AlertDestination?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteAlertDestination = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/AlertDestination?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Alert-API

exports.getAlert = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Alert`, config);
    return response.data;
  } catch (error) {
    // console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getAlertbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Alert/${Id}`, config);
    return response.data;
  } catch (error) {
    // console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createAlert = async (
  id,
  alertDateTime,
  dashboardID,
  alertDestinationID,
  subject,
  message,
  url,
  custom1,
  custom2,
  status
) => {
  try {
    const payload = {
      id: parseInt(id),
      alertDateTime,
      dashboardID: parseInt(dashboardID),
      alertDestinationID: parseInt(alertDestinationID),
      subject,
      message,
      url,
      custom1,
      custom2,
      status,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Alert`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateAlert = async (
  Id,
  id,
  alertDateTime,
  dashboardID,
  alertDestinationID,
  subject,
  message,
  url,
  custom1,
  custom2,
  status
) => {
  try {
    const payload = {
      id: parseInt(id),
      alertDateTime,
      dashboardID: parseInt(dashboardID),
      alertDestinationID: parseInt(alertDestinationID),
      subject,
      message,
      url,
      custom1,
      custom2,
      status,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Alert?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getAlertbySendAlert = async (
  alertDateTime,
  dashboardID,
  alertDestinationID,
  subject,
  message,
  url,
  custom1,
  custom2
) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Alert/sendAlert?dateTime=${alertDateTime}&dashboardId=${dashboardID}&alertDestinationID=${alertDestinationID}&subject=${subject}&message=${message}&url=${url}&custom1=${custom1}&custom2=${custom2}`
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteAlert = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Alert?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Asset - API

exports.getAssetTree = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Asset/tree`, config);
    // console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in models");
  }
};

exports.getAssestbyId = async (Id) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Asset/${Id}`, config);
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getAssetbyassets = async () => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Asset`, config);
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getAssestbychildrenAssestId = async (AssetId) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Asset/children/${AssetId}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getAssetByName = async (name) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Asset/assetByName/${name}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

exports.getAssetbyQuery = async (Name = "", AttributeName = "") => {
  // console.log("getModelbyQuery", Name, AttributeName);
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Asset/query?Name=${Name}&AttributeName=${AttributeName}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in getModelbyassetid");
  }
};

exports.getAssestbyModelid = async (assetModelId) => {
  // console.log("getModelByName",modelName,eotHeaders)
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Asset/assetsbymodelid/${assetModelId}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response.data, "err in getModelbyassetid");
  }
};

//// Object - API

exports.getObject = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Object`, config);
    return response.data;
  } catch (error) {
    // console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getObjectbyId = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(`${eotGatewayUrl}/Object/${Id}`, config);
    return response.data;
  } catch (error) {
    // console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createObject = async (
  id,
  uidig,
  name,
  description,
  graphID,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      uidig,
      name,
      description,
      graphID,
      typeID,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Object`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateObject = async (
  Id,
  id,
  uidig,
  name,
  description,
  graphID,
  typeID,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      uidig,
      name,
      description,
      graphID,
      typeID,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/Object?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteObject = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/Object?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

exports.getObjectList = async (Ids, Names, Requesting) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Object/list?Ids=${Ids}&Names=${Names}&Requesting=${Requesting}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.getObjectMatch = async (
  Id,
  Name,
  RelationshipId,
  RelationshipName,
  Requesting
) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Object/list?Id=${Id}&Name=${Name}&RelationshipId=${RelationshipId}&RelationshipName=${RelationshipName}&Requesting=${Requesting}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getObjectbyquery = async (query) => {
  // console.log("getModelbyQuery", Name, AttributeName);
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Object/query?query=${query}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in getModelbyassetid");
  }
};

exports.getObjectbyJsongraph = async (id, name, isGraph, isFlat, depth) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/Object/jsongraph?Id=${id}&Name=${name}&IsGraph=${isGraph}&IsFlat=${isFlat}&depth=${depth}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.ObjectbyJsonTree = async (value) => {
  try {
    const payload = {
      value,
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/Object/SaveJsonTree`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

//// Object-Attribute

exports.getObjectAttribute = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/ObjectAttribute`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getObjectAttributebyId = async (Id) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/ObjectAttribute/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createObjectAttribute = async (
  id,
  ObjectID,
  attributeID,
  value,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      ObjectID,
      attributeID,
      value,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/ObjectAttribute`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateObjectAttribute = async (
  Id,
  id,
  ObjectID,
  attributeID,
  value,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      ObjectID,
      attributeID,
      value,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/ObjectAttribute?id=${Id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteObjectAttribute = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/ObjectAttribute?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// ObjectRelationshipObject-API

exports.getObjectRelationshipObject = async () => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/ObjectRelationshipObject`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "Error in getRelationshipDef");
    return error.response?.data;
  }
};

exports.getObjectRelationshipObjectbyId = async (Id) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/ObjectRelationshipObject/${Id}`,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.createObjectRelationshipObject = async (
  id,
  objectID1,
  relationshipID,
  objectID2,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      id,
      objectID1,
      relationshipID,
      objectID2,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/ObjectRelationshipObject`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.updateObjectRelationshipObject = async (
  Id,
  id,
  objectID1,
  relationshipID,
  objectID2,
  activatedOn,
  deactivatedOn,
  isActive
) => {
  try {
    const payload = {
      Id,
      id,
      objectID1,
      relationshipID,
      objectID2,
      activatedOn,
      deactivatedOn,
      isActive: isActive.toLowerCase() === "true",
    };
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.put(
      `${eotGatewayUrl}/ObjectRelationshipObject?id=${id}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    console.log(error.response?.data, "err in model");
    return error.response?.data;
  }
};

exports.deleteObjectRelationshipObject = async (Id) => {
  // console.log(Id, "idid");
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.delete(
      `${eotGatewayUrl}/ObjectRelationshipObject?id=${Id}`,
      config
    );
    return "Deleted Successfully";
  } catch (error) {
    return error.response?.data;
  }
};

//// Twinmaker-API

exports.getTwinMaker = async () => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/TwinMaker/workspaces`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};

exports.getTwinmakerbyquery = async (query = "", workspaceId = "") => {
  // console.log("getModelbyQuery", Name, AttributeName);
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.get(
      `${eotGatewayUrl}/TwinMaker/query?query=${query}&workspaceId=${workspaceId}`,
      config
    );
    console.log(response.data);
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in getModelbyassetid");
  }
};

//// SageMaker-API

exports.getSagemakerbyperdictvalues = async (yearsExperience, fileContent) => {
  try {
    const payload = {
      fileContent,
    };

    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    // console.log(payload, "ppp");
    const response = await axios.get(
      `${eotGatewayUrl}/SageMaker/PredictValues?yearsExperience=${yearsExperience}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

//// RuleEngine-API

exports.createruleEnginetreebyCsv = async (
  graphMapId,
  treeName,
  fileContent
) => {
  try {
    const payload = {
      fileContent,
    };

    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    console.log(payload, "payload");
    const response = await axios.post(
      `${eotGatewayUrl}/RuleEngine/CreateTreeViaCSV?graphMapId=${graphMapId}&treeName=${treeName}`,
      payload,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
    console.log(error.response?.data, "err in model");
  }
};

exports.createruleEnginetreebyS3Csv = async (
  dataSourceId,
  graphMapId,
  treeName
) => {
  try {
    const config = {
      headers: eotHeaders,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false,
      }),
    };
    const response = await axios.post(
      `${eotGatewayUrl}/RuleEngine/CreateTreeViaS3CSV?dataSourceId=${dataSourceId}&graphMapId=${graphMapId}&treeName=${treeName}`,
      config
    );
    return response.data;
  } catch (error) {
    return error.response?.data;
  }
};
